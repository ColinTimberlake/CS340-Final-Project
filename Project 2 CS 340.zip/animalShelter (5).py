from pymongo import MongoClient
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        self.client=MongoClient('mongodb://localhost:39064')
        # access the MongoDB databases and collections. 
        #self.client = MongoClient('mongodb://%s:%s@localhost:39064/?authmechanism=DEFAULT&authSource=AAC' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data) #data should be dictionary    
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Create method to implement the R in CRUD.
    
    def read(self, data):
        if data is not None:
            cursor=self.database.animals.find_one(data)
            return cursor
        else:
            raise Exception("Nothing Matching Query Was Found")
            
    def read_all(self, data):
        if data is not None:
            cursor=self.database.animals.find(data, {"_id": False})
            return cursor
        else:
            raise Exception("Nothing Matching Query Was Found")
            
 #Create method to implement the U in CRUD.           
            
    def update(self, data, newData):
        if data is not None:
            result=self.database.animals.update_one(data, newData)
            ### do not return the print output return print(json.dumps(result.raw_result))
            return json.dumps(result.raw_result)
        else:
            raise Exception("Nothing Matching Query Was Found")
        
 #Create method to implement the D in CRUD       
    def delete(self, data):
        if data is not None:
            result=self.database.animals.delete_one(data)
            return json.dumps(result.raw_result) ## was missing return value
        else:
            raise Exception("Nothing Matching Query Was Found")
            